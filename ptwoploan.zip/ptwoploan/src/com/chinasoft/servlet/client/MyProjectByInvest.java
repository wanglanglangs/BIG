package com.chinasoft.servlet.client;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.chinasoft.entity.Project;
import com.chinasoft.service.impl.UserInfoServiceImpl;
@WebServlet("/myproject")
public class MyProjectByInvest extends HttpServlet{
	
	public MyProjectByInvest() {
	}
	
	@Override
	public void destroy() {
		super.destroy();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//��ȡͶ����Ŀ���
		String str = req.getParameter("id");
		//������Ŀ��Ų�ѯͶ����Ŀ��Ϣ
		UserInfoServiceImpl uis = new UserInfoServiceImpl();
		Project pro = uis.queryProjectById(str);
		req.setAttribute("pro", pro);
		//����ת������Ŀ��ϸ��Ϣҳ��
		req.getRequestDispatcher("/client/myaccount/myproject.jsp").forward(req, resp);
	}
	
	@Override
	public void init() throws ServletException {
		super.init();
	}
}
