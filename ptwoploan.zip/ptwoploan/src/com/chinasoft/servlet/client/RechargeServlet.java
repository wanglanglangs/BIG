package com.chinasoft.servlet.client;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.chinasoft.dao.impl.MoneyImpl;
@WebServlet("/recharge")
public class RechargeServlet extends HttpServlet{
	
	public RechargeServlet() {
	}
	
	@Override
	public void init() throws ServletException {
		super.init();
	}
	
	@Override
	public void destroy() {
		super.destroy();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//��ȡ����session�еĵ�ǰ��¼�˻�
		String account =(String) req.getSession().getAttribute("useraccount");
		//�����˻�����ѯ��ǰ�û����,Ȼ�����request��
		MoneyImpl mi = new MoneyImpl();
		int balance = mi.showMoneyByAccount(account);
		req.setAttribute("blance", balance);
		//����ת�����ҵ��˻�ҳ��
		req.getRequestDispatcher("/client/myaccount/recharge.jsp").forward(req, resp);
	}
	
	
}
