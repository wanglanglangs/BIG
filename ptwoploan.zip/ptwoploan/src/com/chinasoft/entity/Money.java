package com.chinasoft.entity;

public class Money {
	private String account;
	private int money;
	public Money(String account, int money) {
		super();
		this.account = account;
		this.money = money;
	}
	public Money() {
		super();
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}

}
