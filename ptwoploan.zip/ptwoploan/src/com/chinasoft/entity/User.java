package com.chinasoft.entity;
/*
 * ����˻�����Ϣ��
 */
public class User {
	
	private int id;//�����ID
	private String account;//������˺�
	private String pass;//���������
	private String tel;//����˵绰
	private String name;//���������
	private String address;//����˵�ַ
	private String idcart;//���������֤
	private String company;//����˹�˾
	private String otherinfor;//�������ϸ����
	private String salary;//����˹���
	
	public User() {
		super();
	}

	public User(int id, String account, String pass, String tel, String name,
			String address, String idcart, String company, String otherinfor,
			String salary) {
		super();
		this.id = id;
		this.account = account;
		this.pass = pass;
		this.tel = tel;
		this.name = name;
		this.address = address;
		this.idcart = idcart;
		this.company = company;
		this.otherinfor = otherinfor;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getIdcart() {
		return idcart;
	}

	public void setIdcart(String idcart) {
		this.idcart = idcart;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getOtherinfor() {
		return otherinfor;
	}

	public void setOtherinfor(String otherinfor) {
		this.otherinfor = otherinfor;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return " �������Ϣ��id=" + id + ", account=" + account + ", pass=" + pass
				+ ", tel=" + tel + ", name=" + name + ", address=" + address
				+ ", idcart=" + idcart + ", company=" + company
				+ ", otherinfor=" + otherinfor + ", salary=" + salary + "";
	}
	
	
	
	
	
	

}
