package com.chinasoft.dao;

import java.util.List;

import com.chinasoft.entity.Manager;

public interface ManagerDao {
	
	public boolean getAll(String m_account ,String m_pass);

}
