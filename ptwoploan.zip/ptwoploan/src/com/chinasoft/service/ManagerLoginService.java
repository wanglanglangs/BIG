package com.chinasoft.service;

import java.util.List;

import com.chinasoft.entity.Manager;

public interface ManagerLoginService {
	
	public boolean get(String m_account ,String m_pass);

}
